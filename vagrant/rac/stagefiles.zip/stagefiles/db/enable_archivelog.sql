shutdown immediate
startup mount
alter database archivelog ;
alter database open ;
alter system archive log current;
exit;
