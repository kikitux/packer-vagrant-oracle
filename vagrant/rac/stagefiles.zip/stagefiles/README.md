stagefiles
==========

1. review db/zip/required_files.txt and place in db/zip the files listed there
2. update os/repo.env with the url of your internal repo, if none, then set http://public-yum.oracle.com

